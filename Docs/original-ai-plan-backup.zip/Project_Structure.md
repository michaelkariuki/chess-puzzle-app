# Chess Puzzle App - Project Structure & Templates

## Complete Project Structure

This document defines the complete project structure following framework-agnostic principles and Kilo Code Software Development Rules.

```
ChessPuzzleApp/
├── README.md                           # Project overview and setup
├── package.json                        # Dependencies and scripts
├── tsconfig.json                       # TypeScript configuration
├── jest.config.js                      # Jest testing configuration
├── metro.config.js                     # Metro bundler configuration
├── app.json                            # Expo app configuration
├── eas.json                            # EAS Build configuration
│
├── .github/                            # CI/CD workflows
│   └── workflows/
│       ├── ci.yml                      # Continuous integration
│       ├── e2e.yml                     # End-to-end testing
│       └── deploy.yml                  # Deployment automation
│
├── src/                                # Application source code
│   ├── App.tsx                         # Root application component
│   │
│   ├── core/                           # Framework-agnostic business logic
│   │   ├── chess/                      # Chess-specific logic
│   │   │   ├── Position.ts             # Position handling and FEN parsing
│   │   │   ├── Move.ts                 # Move generation and validation
│   │   │   ├── Piece.ts                # Chess piece logic
│   │   │   ├── Board.ts                # Board geometry and utilities
│   │   │   ├── Game.ts                 # Game state management
│   │   │   └── index.ts                # Chess module exports
│   │   │
│   │   ├── puzzles/                    # Puzzle-specific logic
│   │   │   ├── Puzzle.ts               # Puzzle data models
│   │   │   ├── Solver.ts               # Solution validation
│   │   │   ├── Generator.ts            # Custom puzzle generation
│   │   │   ├── Validator.ts            # Puzzle integrity checking
│   │   │   └── index.ts                # Puzzles module exports
│   │   │
│   │   ├── rating/                     # Rating and difficulty system
│   │   │   ├── Elo.ts                  # Elo rating calculation
│   │   │   ├── Glicko2.ts              # Glicko-2 rating system
│   │   │   ├── Progression.ts          # Difficulty adjustment
│   │   │   ├── Performance.ts          # Performance tracking
│   │   │   └── index.ts                # Rating module exports
│   │   │
│   │   ├── storage/                    # Data persistence abstraction
│   │   │   ├── Repository.ts           # Repository pattern interface
│   │   │   ├── Cache.ts                # Caching strategy
│   │   │   ├── SyncManager.ts          # Data synchronization
│   │   │   └── index.ts                # Storage module exports
│   │   │
│   │   ├── interfaces/                 # TypeScript interfaces
│   │   │   ├── Chess.ts                # Chess-related interfaces
│   │   │   ├── Puzzle.ts               # Puzzle-related interfaces
│   │   │   ├── User.ts                 # User-related interfaces
│   │   │   ├── API.ts                  # API-related interfaces
│   │   │   └── index.ts                # Interface exports
│   │   │
│   │   └── utils/                      # Utility functions
│   │       ├── validators/             # Input validation
│   │       ├── formatters/             # Data formatting
│   │       ├── helpers/                # General helpers
│   │       └── index.ts                # Utils exports
│   │
│   ├── adapters/                       # Framework-specific implementations
│   │   ├── react-native/               # React Native adapters
│   │   │   ├── UI/                     # UI components
│   │   │   │   ├── ChessBoard/
│   │   │   │   │   ├── ChessBoard.tsx  # Main chess board component
│   │   │   │   │   ├── Square.tsx      # Individual square component
│   │   │   │   │   ├── Piece.tsx       # Chess piece component
│   │   │   │   │   └── styles.ts       # Board styling
│   │   │   │   │
│   │   │   │   ├── PuzzleList/
│   │   │   │   │   ├── PuzzleList.tsx  # Puzzle list component
│   │   │   │   │   ├── PuzzleItem.tsx  # Individual puzzle item
│   │   │   │   │   └── styles.ts       # List styling
│   │   │   │   │
│   │   │   │   ├── Statistics/
│   │   │   │   │   ├── Statistics.tsx  # Statistics dashboard
│   │   │   │   │   ├── Charts.tsx      # Performance charts
│   │   │   │   │   └── styles.ts       # Statistics styling
│   │   │   │   │
│   │   │   │   ├── Common/
│   │   │   │   │   ├── Button.tsx      # Reusable button component
│   │   │   │   │   ├── LoadingSpinner.tsx # Loading indicator
│   │   │   │   │   ├── ErrorBoundary.tsx # Error handling
│   │   │   │   │   └── styles.ts       # Common styling
│   │   │   │   │
│   │   │   │   └── index.ts            # UI component exports
│   │   │   │
│   │   │   ├── Navigation/             # Navigation setup
│   │   │   │   ├── AppNavigator.tsx    # Main navigation container
│   │   │   │   ├── HomeNavigator.tsx   # Home screen navigation
│   │   │   │   ├── PuzzleNavigator.tsx # Puzzle screen navigation
│   │   │   │   └── types.ts            # Navigation types
│   │   │   │
│   │   │   ├── Storage/                # Storage implementations
│   │   │   │   ├── AsyncStorage.ts     # AsyncStorage adapter
│   │   │   │   ├── SecureStorage.ts    # Encrypted storage
│   │   │   │   └── StateManager.ts     # State persistence
│   │   │   │
│   │   │   ├── Context/                # React Context providers
│   │   │   │   ├── AppContext.tsx      # Global app state
│   │   │   │   ├── PuzzleContext.tsx   # Puzzle state management
│   │   │   │   └── ThemeContext.tsx    # Theme management
│   │   │   │
│   │   │   └── index.ts                # React Native adapter exports
│   │   │
│   │   ├── chess-engines/              # Chess engine adapters
│   │   │   ├── ChessJS.ts              # chess.js wrapper
│   │   │   ├── Stockfish.ts            # Stockfish WASM integration
│   │   │   ├── EngineFactory.ts        # Engine factory pattern
│   │   │   └── index.ts                # Engine adapter exports
│   │   │
│   │   └── external/                   # External service clients
│   │       ├── LichessAPI.ts           # Lichess API client
│   │       ├── HttpClient.ts           # HTTP request wrapper
│   │       ├── RateLimiter.ts          # API rate limiting
│   │       └── index.ts                # External adapter exports
│   │
│   ├── features/                       # Feature modules
│   │   ├── home/                       # Home screen feature
│   │   │   ├── HomeScreen.tsx          # Home screen component
│   │   │   ├── HomeViewModel.ts        # Home screen logic
│   │   │   ├── QuickPlay.tsx           # Quick play component
│   │   │   └── styles.ts               # Home screen styling
│   │   │
│   │   ├── puzzle-solving/             # Puzzle solving feature
│   │   │   ├── PuzzleScreen.tsx        # Main puzzle screen
│   │   │   ├── PuzzleViewModel.ts      # Puzzle solving logic
│   │   │   ├── MoveInput.tsx           # Move input component
│   │   │   ├── SolutionDisplay.tsx     # Solution display
│   │   │   ├── Hints.tsx               # Hint system
│   │   │   └── styles.ts               # Puzzle solving styling
│   │   │
│   │   ├── statistics/                 # Statistics feature
│   │   │   ├── StatisticsScreen.tsx    # Statistics screen
│   │   │   ├── StatisticsViewModel.ts  # Statistics logic
│   │   │   ├── PerformanceCharts.tsx   # Chart components
│   │   │   ├── AchievementList.tsx     # Achievement display
│   │   │   └── styles.ts               # Statistics styling
│   │   │
│   │   ├── settings/                   # Settings feature
│   │   │   ├── SettingsScreen.tsx      # Settings screen
│   │   │   ├── SettingsViewModel.ts    # Settings logic
│   │   │   ├── ThemeSettings.tsx       # Theme configuration
│   │   │   ├── GameSettings.tsx        # Game preferences
│   │   │   └── styles.ts               # Settings styling
│   │   │
│   │   └── puzzle-editor/              # Puzzle editor feature (future)
│   │       ├── EditorScreen.tsx        # Editor screen
│   │       ├── EditorViewModel.ts      # Editor logic
│   │       ├── PositionEditor.tsx      # Position editing
│   │       └── styles.ts               # Editor styling
│   │
│   ├── services/                       # Business logic services
│   │   ├── PuzzleService.ts            # Puzzle management service
│   │   ├── RatingService.ts            # Rating calculation service
│   │   ├── SyncService.ts              # Data synchronization service
│   │   ├── AnalyticsService.ts         # Analytics and metrics
│   │   ├── ThemeService.ts             # Theme management service
│   │   └── index.ts                    # Service exports
│   │
│   ├── hooks/                          # Custom React hooks
│   │   ├── usePuzzle.ts                # Puzzle-related hooks
│   │   ├── useRating.ts                # Rating-related hooks
│   │   ├── useTheme.ts                 # Theme-related hooks
│   │   ├── useStorage.ts               # Storage-related hooks
│   │   ├── useOnlineStatus.ts          # Online status detection
│   │   └── index.ts                    # Hook exports
│   │
│   ├── constants/                      # Application constants
│   │   ├── Colors.ts                   # Color palette
│   │   ├── Dimensions.ts               # Screen dimensions
│   │   ├── Themes.ts                   # Theme definitions
│   │   ├── Config.ts                   # App configuration
│   │   ├── Assets.ts                   # Asset references
│   │   └── index.ts                    # Constants exports
│   │
│   ├── types/                          # TypeScript type definitions
│   │   ├── navigation.ts               # Navigation types
│   │   ├── theme.ts                    # Theme types
│   │   ├── puzzle.ts                   # Puzzle types
│   │   └── index.ts                    # Type exports
│   │
│   └── styles/                         # Global styles
│       ├── global.ts                   # Global style definitions
│       ├── themes.ts                   # Theme styles
│       └── index.ts                    # Style exports
│
├── assets/                             # Static assets
│   ├── images/                         # Images and icons
│   │   ├── pieces/                     # Chess piece images
│   │   ├── backgrounds/                # Background images
│   │   ├── logos/                      # App logos
│   │   └── ui/                         # UI elements
│   │
│   ├── sounds/                         # Audio files
│   │   ├── move.wav                    # Move sound
│   │   ├── capture.wav                 # Capture sound
│   │   ├── check.wav                   # Check sound
│   │   └── checkmate.wav               # Checkmate sound
│   │
│   └── fonts/                          # Custom fonts
│       ├── ChessFont.ttf               # Chess symbols font
│       └── UI-Font.ttf                 # UI font
│
├── __tests__/                          # Test files
│   ├── unit/                           # Unit tests
│   │   ├── core/                       # Core logic tests
│   │   │   ├── chess/                  # Chess logic tests
│   │   │   │   ├── Position.test.ts    # Position tests
│   │   │   │   ├── Move.test.ts        # Move tests
│   │   │   │   └── Game.test.ts        # Game tests
│   │   │   │
│   │   │   ├── puzzles/                # Puzzle logic tests
│   │   │   │   ├── Puzzle.test.ts      # Puzzle tests
│   │   │   │   └── Solver.test.ts      # Solver tests
│   │   │   │
│   │   │   └── rating/                 # Rating system tests
│   │   │       ├── Elo.test.ts         # Elo tests
│   │   │       └── Progression.test.ts # Progression tests
│   │   │
│   │   ├── services/                   # Service tests
│   │   │   ├── PuzzleService.test.ts   # Puzzle service tests
│   │   │   ├── RatingService.test.ts   # Rating service tests
│   │   │   └── SyncService.test.ts     # Sync service tests
│   │   │
│   │   └── utils/                      # Utility tests
│   │       ├── validators/             # Validation tests
│   │       └── formatters/             # Formatting tests
│   │
│   ├── integration/                    # Integration tests
│   │   ├── api/                        # API integration tests
│   │   │   ├── LichessAPI.test.ts      # Lichess API tests
│   │   │   └── Storage.test.ts         # Storage tests
│   │   │
│   │   ├── components/                 # Component integration tests
│   │   │   ├── ChessBoard.test.tsx     # Chess board tests
│   │   │   └── PuzzleList.test.tsx     # Puzzle list tests
│   │   │
│   │   └── services/                   # Service integration tests
│   │       ├── CompleteWorkflow.test.ts # End-to-end workflows
│   │       └── DataSync.test.ts        # Data synchronization tests
│   │
│   ├── e2e/                            # End-to-end tests (Detox)
│   │   ├── puzzle-solving.e2e.ts       # Puzzle solving flow
│   │   ├── statistics.e2e.ts           # Statistics viewing
│   │   ├── settings.e2e.ts             # Settings management
│   │   └── offline-mode.e2e.ts         # Offline functionality
│   │
│   └── performance/                    # Performance tests
│       ├── PuzzleLoading.test.ts       # Loading performance
│       ├── MemoryUsage.test.ts         # Memory usage tests
│       └── BundleSize.test.ts          # Bundle size tests
│
├── docs/                               # Project documentation
│   ├── architecture/                   # Architecture documentation
│   │   ├── adr-001-core-design.md      # Architecture decision records
│   │   ├── adr-002-data-layer.md       # Data layer decisions
│   │   ├── system-overview.md          # System overview
│   │   └── patterns.md                 # Design patterns used
│   │
│   ├── api/                            # API documentation
│   │   ├── endpoints.md                # API endpoints
│   │   ├── data-models.md              # Data model reference
│   │   ├── examples.md                 # Usage examples
│   │   └── errors.md                   # Error handling
│   │
│   ├── development/                    # Development documentation
│   │   ├── setup.md                    # Development setup guide
│   │   ├── coding-standards.md         # Coding standards
│   │   ├── contributing.md             # Contributing guidelines
│   │   └── troubleshooting.md          # Common issues
│   │
│   ├── deployment/                     # Deployment documentation
│   │   ├── build-process.md            # Build process guide
│   │   ├── app-store.md                # App store submission
│   │   └── monitoring.md               # App monitoring
│   │
│   └── user/                           # User documentation
│       ├── user-guide.md               # End-user guide
│       ├── faq.md                      # Frequently asked questions
│       └── screenshots.md              # UI screenshots
│
├── scripts/                            # Build and utility scripts
│   ├── setup.sh                        # Development environment setup
│   ├── build.sh                        # Build script
│   ├── test.sh                         # Test runner script
│   ├── lint.sh                         # Code linting script
│   └── deploy.sh                       # Deployment script
│
└── .vscode/                            # VS Code configuration
    ├── extensions.json                 # Recommended extensions
    ├── settings.json                   # Workspace settings
    └── launch.json                     # Debug configurations
```

## Core Module Templates

### Chess Module Template
```typescript
// src/core/chess/Position.ts
export interface Position {
  fen: string;
  turn: 'white' | 'black';
  castling: CastlingRights;
  enPassant: string | null;
  halfmove: number;
  fullmove: number;
}

export interface CastlingRights {
  whiteKingside: boolean;
  whiteQueenside: boolean;
  blackKingside: boolean;
  blackQueenside: boolean;
}

export class Position {
  private readonly position: PositionData;

  constructor(fen: string) {
    this.position = this.parseFEN(fen);
  }

  // Core position methods
  getLegalMoves(): Move[] {
    // Implementation
  }

  isValidMove(move: Move): boolean {
    // Implementation
  }

  applyMove(move: Move): Position {
    // Implementation
  }

  private parseFEN(fen: string): PositionData {
    // FEN parsing implementation
  }
}
```

### Service Layer Template
```typescript
// src/services/PuzzleService.ts
import { Repository } from '../core/storage/Repository';
import { RatingService } from './RatingService';
import { CacheService } from './CacheService';

export class PuzzleService {
  constructor(
    private puzzleRepository: Repository<Puzzle>,
    private ratingService: RatingService,
    private cacheService: CacheService
  ) {}

  async getNextPuzzle(userRating: number): Promise<Puzzle> {
    // Business logic for puzzle selection
    const targetRating = this.ratingService.calculateTargetRating(userRating);
    return this.puzzleRepository.findBestMatch(targetRating);
  }

  async saveSolution(puzzleId: string, solution: SolutionResult): Promise<void> {
    // Business logic for saving solutions
  }
}
```

### React Component Template
```typescript
// src/adapters/react-native/UI/ChessBoard/ChessBoard.tsx
import React, { useCallback, useMemo } from 'react';
import { View } from 'react-native';
import { Position, Move } from '../../../../core/chess';
import { ChessBoardProps } from './types';

export const ChessBoard: React.FC<ChessBoardProps> = React.memo(
  ({ position, interactive, onMove, theme }) => {
    // Component logic
    const handleSquarePress = useCallback((square: string) => {
      if (!interactive) return;
      // Square press handling logic
    }, [interactive, position]);

    const squares = useMemo(() => {
      return position.getSquares().map(square => (
        <Square
          key={square}
          square={square}
          onPress={() => handleSquarePress(square)}
          theme={theme}
        />
      ));
    }, [position, theme, handleSquarePress]);

    return (
      <View style={styles.board}>
        {squares}
      </View>
    );
  }
);
```

## Configuration Files

### TypeScript Configuration
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "esnext",
    "moduleResolution": "node",
    "lib": ["ES2020"],
    "jsx": "react-native",
    "allowJs": true,
    "noEmit": true,
    "isolatedModules": true,
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true,
    "noImplicitOverride": true,
    "skipLibCheck": true,
    "resolveJsonModule": true,
    "baseUrl": "./src",
    "paths": {
      "@/*": ["*"],
      "@core/*": ["core/*"],
      "@adapters/*": ["adapters/*"],
      "@services/*": ["services/*"],
      "@types/*": ["types/*"]
    }
  },
  "include": [
    "src/**/*",
    "__tests__/**/*",
    "*.ts",
    "*.tsx"
  ],
  "exclude": [
    "node_modules",
    "dist"
  ]
}
```

### Jest Configuration
```javascript
module.exports = {
  preset: 'jest-expo',
  transformIgnorePatterns: [
    'node_modules/(?!((jest-)?react-native|@react-native(-community)?)|expo(nent)?|@expo(nent)?/.*|@expo-google-fonts/.*|react-navigation|@react-navigation/.*|@unimodules/.*|unimodules|sentry-expo|native-base|react-native-svg)'
  ],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  setupFilesAfterEnv: ['<rootDir>/__tests__/setup.ts'],
  collectCoverageFrom: [
    'src/core/**/*.{ts,tsx}',
    'src/services/**/*.{ts,tsx}',
    'src/adapters/**/*.{ts,tsx}',
    '!src/**/*.d.ts'
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80
    }
  },
  testMatch: [
    '<rootDir>/__tests__/unit/**/*.test.{ts,tsx}',
    '<rootDir>/__tests__/integration/**/*.test.{ts,tsx}'
  ]
};
```

### Metro Configuration
```javascript
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

config.resolver.sourceExts.push('cjs');

module.exports = config;
```

### EAS Build Configuration
```json
{
  "cli": {
    "version": ">= 3.0.0"
  },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    },
    "preview": {
      "distribution": "internal",
      "ios": {
        "simulator": true
      }
    },
    "production": {}
  },
  "submit": {
    "production": {
      "ios": {
        "appleId": "your-apple-id@example.com",
        "ascAppId": "1234567890",
        "appleTeamId": "XXXXXXXXXX"
      },
      "android": {
        "serviceAccountKeyPath": "../path/to/api-key.json",
        "track": "internal"
      }
    }
  }
}
```

## Package.json Scripts

```json
{
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios",
    "web": "expo start --web",
    "build:android": "eas build --platform android",
    "build:ios": "eas build --platform ios",
    "build:all": "eas build --platform all",
    "test": "jest",
    "test:coverage": "jest --coverage",
    "test:watch": "jest --watch",
    "test:e2e": "detox test --configuration ios.sim.release",
    "lint": "eslint src --ext .ts,.tsx",
    "lint:fix": "eslint src --ext .ts,.tsx --fix",
    "type-check": "tsc --noEmit",
    "format": "prettier --write src",
    "setup": "bash scripts/setup.sh",
    "clean": "expo r -c",
    "doctor": "expo doctor",
    "deploy:preview": "eas build --profile preview --platform all",
    "deploy:production": "eas build --profile production --platform all"
  }
}
```

## Git Configuration

### .gitignore
```
# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Expo
.expo/
dist/
web-build/

# Native
*.orig.*
*.jks
*.p8
*.p12
*.key
*.mobileprovision

# Metro
.metro-health-check*

# Debug
npm-debug.*
yarn-debug.*
yarn-error.*

# MacOS
.DS_Store
*.pem

# Local env files
.env.local
.env.development.local
.env.test.local
.env.production.local

# Testing
coverage/
*.lcov

# IDE
.vscode/
.idea/
*.swp
*.swo

# Logs
logs
*.log

# Runtime data
pids
*.pid
*.seed
*.pid.lock

# Temporary folders
tmp/
temp/

# Build outputs
build/
dist/

# Cache
.cache/
.eslintcache
.stylelintcache
```

### Commit Message Convention
```bash
# Conventional Commits format
type(scope): description

# Examples:
feat(puzzle): add difficulty adjustment algorithm
fix(chess): resolve FEN parsing edge case
test(rating): add unit tests for Elo calculation
docs(api): update API documentation
refactor(UI): optimize ChessBoard rendering performance
perf(engine): improve Stockfish integration speed
style(components): apply consistent formatting
chore(deps): update chess.js to latest version
```

This comprehensive project structure ensures maintainable, scalable, and well-organized code following the Kilo Code Software Development Rules.