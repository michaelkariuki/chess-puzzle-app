# Chess Puzzle App - API Documentation & Data Models

## Table of Contents

1. [Core Data Models](#core-data-models)
2. [External API Integration](#external-api-integration)
3. [Internal Service APIs](#internal-service-apis)
4. [Storage Interfaces](#storage-interfaces)
5. [Event System](#event-system)
6. [Type Definitions](#type-definitions)
7. [Error Handling](#error-handling)

---

## Core Data Models

### 1. Chess Position Model

```typescript
// src/core/interfaces/Chess.ts

export interface Position {
  fen: string;
  turn: 'white' | 'black';
  castlingRights: CastlingRights;
  enPassant: Square | null;
  halfmoveClock: number;
  fullmoveNumber: number;
  history: PositionHistory[];
}

export interface CastlingRights {
  whiteKingside: boolean;
  whiteQueenside: boolean;
  blackKingside: boolean;
  blackQueenside: boolean;
}

export interface PositionHistory {
  fen: string;
  move: Move;
  capture: Piece | null;
  check: boolean;
  checkmate: boolean;
}

export interface Square {
  file: File; // 'a' through 'h'
  rank: Rank; // 1 through 8
  index: number; // 0-63 for internal representation
}

export type File = 'a' | 'b' | 'c' | 'd' | 'e' | 'f' | 'g' | 'h';
export type Rank = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;

export interface Move {
  from: Square;
  to: Square;
  promotion?: PieceType;
  isCapture: boolean;
  isCheck: boolean;
  isCheckmate: boolean;
  isCastling: boolean;
  notation: string; // UCI notation: "e2e4", "e7e8q"
  san: string; // SAN notation: "e4", "O-O", "exd5+"
}

export interface Piece {
  type: PieceType;
  color: Color;
  square: Square;
  hasMoved: boolean;
}

export type PieceType = 'pawn' | 'knight' | 'bishop' | 'rook' | 'queen' | 'king';
export type Color = 'white' | 'black';

export interface GameState {
  status: GameStatus;
  position: Position;
  moves: Move[];
  currentMove: number;
  result?: GameResult;
  termination?: TerminationReason;
}

export type GameStatus = 'in-progress' | 'check' | 'checkmate' | 'stalemate' | 'draw' | 'abandoned';
export type GameResult = '1-0' | '0-1' | '1/2-1/2';
export type TerminationReason = 'checkmate' | 'stalemate' | 'draw' | 'resignation' | 'timeout';
```

### 2. Puzzle Model

```typescript
// src/core/interfaces/Puzzle.ts

export interface Puzzle {
  id: string;
  fen: string;
  solution: Move[];
  alternativeLines: AlternativeLine[];
  rating: PuzzleRating;
  theme: PuzzleTheme;
  metadata: PuzzleMetadata;
  userProgress?: UserProgress;
}

export interface AlternativeLine {
  moves: Move[];
  description: string;
  evaluation?: number;
  isBestLine: boolean;
}

export interface PuzzleRating {
  glicko2: number;
  deviation: number;
  volatility: number;
  lastUpdated: Date;
}

export interface PuzzleTheme {
  primary: PuzzleThemeType;
  secondary: PuzzleThemeType[];
  tags: string[];
}

export type PuzzleThemeType =
  | 'fork' | 'pin' | 'skewer' | 'discoveredAttack' | 'doubleAttack'
  | 'sacrifice' | 'deflection' | 'decoy' | 'interference' | 'overloading'
  | 'clearance' | 'interposing' | 'annihilation' | 'blocking' | 'hook'
  | 'lure' | 'quietMove' | 'zugzwang' | 'endgame' | 'opening'
  | 'middlegame' | 'tactical' | 'positional';

export interface PuzzleMetadata {
  source: PuzzleSource;
  gameId?: string;
  moveNumber: number;
 ply: number;
  fenBefore: string;
  lastMove: Move;
  whiteElo?: number;
  blackElo?: number;
  timeControl?: string;
  createdAt: Date;
  popularity?: number;
  plays: number;
  themes: string[];
}

export type PuzzleSource = 'lichess' | 'custom' | 'stockfish' | 'user-created';

export interface UserProgress {
  attempts: number;
  solved: boolean;
  solvedAt?: Date;
  timeToSolve?: number;
  hintUsed: boolean;
  firstTrySuccess: boolean;
  userRating?: number;
  performance?: PerformanceMetrics;
}

export interface PerformanceMetrics {
  accuracy: number;
  timeEfficiency: number;
  moveAccuracy: number;
  hintDependency: number;
  streakCount: number;
}
```

### 3. User Model

```typescript
// src/core/interfaces/User.ts

export interface User {
  id: string;
  profile: UserProfile;
  rating: UserRating;
  progress: UserProgress;
  preferences: UserPreferences;
  statistics: UserStatistics;
  achievements: Achievement[];
}

export interface UserProfile {
  username: string;
  email?: string;
  avatar?: string;
  joinDate: Date;
  lastActiveDate: Date;
  timezone: string;
  locale: string;
  isGuest: boolean;
}

export interface UserRating {
  current: number;
  peak: number;
  deviation: number;
  lastUpdated: Date;
  progress: RatingProgress[];
}

export interface RatingProgress {
  date: Date;
  rating: number;
  change: number;
  source: string;
}

export interface UserProgress {
  totalSolved: number;
  currentStreak: number;
  bestStreak: number;
  totalAttempts: number;
  accuracy: number;
  averageTime: number;
  favoriteThemes: PuzzleThemeType[];
  recentPerformance: PerformanceSnapshot[];
}

export interface PerformanceSnapshot {
  date: Date;
  puzzlesSolved: number;
  accuracy: number;
  averageTime: number;
  ratingChange: number;
}

export interface UserPreferences {
  theme: Theme;
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  soundEnabled: boolean;
  animationEnabled: boolean;
  autoPlayMoves: boolean;
  showCoordinates: boolean;
  showLastMove: boolean;
  showLegalMoves: boolean;
  difficultyPreference: DifficultyPreference;
  language: string;
}

export type Theme = 'light' | 'dark' | 'system';
export type BoardTheme = 'classic' | 'blue' | 'green' | 'brown' | 'gray';
export type PieceTheme = 'classic' | 'unicode' | 'modern' | 'minimal';
export type DifficultyPreference = 'easier' | 'balanced' | 'harder' | 'adaptive';

export interface UserStatistics {
  daily: DailyStats;
  weekly: WeeklyStats;
  monthly: MonthlyStats;
  yearly: YearlyStats;
  allTime: AllTimeStats;
}

export interface DailyStats {
  date: Date;
  puzzlesSolved: number;
  accuracy: number;
  timeSpent: number;
  newRating?: number;
}

export interface WeeklyStats {
  weekStart: Date;
  puzzlesSolved: number;
  totalTime: number;
  averageAccuracy: number;
  ratingChange: number;
  streak: number;
}

export interface MonthlyStats {
  monthStart: Date;
  totalPuzzles: number;
  totalTime: number;
  averageAccuracy: number;
  ratingChange: number;
  bestDay: DailyStats;
  improvement: number;
}

export interface YearlyStats {
  year: number;
  totalPuzzles: number;
  totalTime: number;
  averageAccuracy: number;
  ratingChange: number;
  milestones: Milestone[];
  rank: string;
}

export interface AllTimeStats {
  firstPuzzleDate: Date;
  totalPuzzles: number;
  totalTime: number;
  averageAccuracy: number;
  peakRating: number;
  totalStreak: number;
  rank: string;
  percentile: number;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: AchievementCategory;
  tier: AchievementTier;
  unlockedAt: Date;
  progress?: AchievementProgress;
}

export type AchievementCategory =
  | 'solving' | 'accuracy' | 'streak' | 'rating' | 'time' | 'variety' | 'special';
export type AchievementTier = 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';

export interface AchievementProgress {
  current: number;
  target: number;
  percentage: number;
  milestone?: string;
}
```

---

## External API Integration

### 1. Lichess API Client

```typescript
// src/adapters/external/LichessAPI.ts

export interface LichessAPIClient {
  // Puzzle fetching
  fetchDailyPuzzle(): Promise<Puzzle>;
  fetchPuzzles(params: PuzzleQueryParams): Promise<PuzzleBatch>;
  fetchPuzzleById(id: string): Promise<Puzzle | null>;

  // Game data
  fetchGameById(gameId: string): Promise<GameData | null>;
  fetchPlayerGames(playerId: string, params?: GameQueryParams): Promise<GameData[]>;

  // User data
  fetchUserProfile(playerId: string): Promise<UserData | null>;
  fetchUserStats(playerId: string): Promise<UserStats | null>;
}

export interface PuzzleQueryParams {
  max?: number;
  minRating?: number;
  maxRating?: number;
  theme?: PuzzleThemeType;
  tags?: string[];
  since?: Date;
  until?: Date;
}

export interface PuzzleBatch {
  puzzles: Puzzle[];
  nextCursor?: string;
  total: number;
  lastUpdated: Date;
}

export interface GameData {
  id: string;
  players: Player[];
  clock?: ClockInfo;
  rated: boolean;
  perf: string;
  createdAt: Date;
  lastMoveAt: Date;
  status: string;
  pgn: string;
  moves: string;
  white?: PlayerData;
  black?: PlayerData;
  winner?: Color;
  opening?: OpeningInfo;
  analyse?: AnalysisInfo;
}

export interface Player {
  color: Color;
  name: string;
  rating?: number;
  ratingDiff?: number;
}

export interface PlayerData {
  id: string;
  username: string;
  rating: number;
  ratingDiff: number;
  result: string;
  playTime: number;
  bot: boolean;
}

export interface ClockInfo {
  initial: number;
  increment: number;
  totalTime: number;
}

export interface OpeningInfo {
  eco: string;
  name: string;
  ply: number;
}

export interface AnalysisInfo {
  by?: string;
  inAccuracy?: number;
  mistake?: number;
  blunder?: number;
}

export interface UserData {
  id: string;
  username: string;
  profile: UserProfileData;
  counts: UserCounts;
  playing: string;
  createdAt: Date;
  seenAt: Date;
  playTime: number;
}

export interface UserProfileData {
  country?: string;
  location?: string;
  bio?: string;
  firstName?: string;
  lastName?: string;
  fide?: number;
  links?: string;
}

export interface UserCounts {
  all: number;
  rated: number;
  ai: number;
  draw: number;
  drawH: number;
  loss: number;
  lossH: number;
  win: number;
  winH: number;
  playing: number;
  import: number;
}

export interface UserStats {
  { [key: string]: PerfStats };
}

export interface PerfStats {
  games: number;
  rating: number;
  rd: number;
  prog: number;
  prov: boolean;
}
```

### 2. Chess Engine Interface

```typescript
// src/adapters/chess-engines/EngineInterface.ts

export interface ChessEngine {
  initialize(): Promise<void>;
  analyzePosition(fen: string, options?: AnalysisOptions): Promise<AnalysisResult>;
  findBestMove(fen: string, options?: MoveOptions): Promise<Move | null>;
  evaluatePosition(fen: string): Promise<Evaluation>;
  generatePuzzle(position: Position, theme: PuzzleTheme, difficulty: number): Promise<Puzzle>;
  isReady(): boolean;
  terminate(): Promise<void>;
}

export interface AnalysisOptions {
  depth?: number;
  time?: number; // milliseconds
  nodes?: number;
  multipv?: number; // multi-principal variation
  skill?: number; // 0-20, lower = weaker
  threads?: number;
  hash?: number; // MB
}

export interface MoveOptions {
  depth?: number;
  time?: number;
  skill?: number;
  movetime?: number;
}

export interface AnalysisResult {
  depth: number;
  evaluation: Evaluation;
  bestMove: Move | null;
  principalVariation: Move[];
  nodes: number;
  time: number;
  nps: number; // nodes per second
  multipv: PrincipalVariation[];
}

export interface Evaluation {
  type: 'cp' | 'mate';
  value: number; // centipawns if cp, moves if mate
  mateIn?: number;
  winrate?: number;
  isDrawing?: boolean;
  isWinning?: boolean;
}

export interface PrincipalVariation {
  score: Evaluation;
  move: Move;
  variation: Move[];
}

export interface PositionEvaluation {
  fen: string;
  evaluation: Evaluation;
  bestMove: Move | null;
  continuation: Move[];
  tactics: TacticalOpportunity[];
}

export interface TacticalOpportunity {
  type: PuzzleThemeType;
  moves: Move[];
  difficulty: number;
  evaluation: number;
  description: string;
}
```

---

## Internal Service APIs

### 1. Puzzle Service

```typescript
// src/services/PuzzleService.ts

export class PuzzleService {
  // Puzzle retrieval
  getNextPuzzle(userRating: number, preferences?: PuzzlePreferences): Promise<Puzzle>;
  getRandomPuzzle(theme?: PuzzleThemeType): Promise<Puzzle>;
  getPuzzleById(id: string): Promise<Puzzle | null>;
  searchPuzzles(criteria: SearchCriteria): Promise<Puzzle[]>;

  // Puzzle solving
  submitSolution(puzzleId: string, moves: Move[]): Promise<SolutionResult>;
  requestHint(puzzleId: string, step: number): Promise<Hint>;
  skipPuzzle(puzzleId: string): Promise<void>;

  // Custom puzzles
  generateCustomPuzzle(options: GenerationOptions): Promise<Puzzle>;
  createPuzzleFromPosition(position: Position): Promise<Puzzle>;
  validateCustomPuzzle(puzzle: Puzzle): Promise<ValidationResult>;
}

export interface PuzzlePreferences {
  themes?: PuzzleThemeType[];
  ratingRange?: { min: number; max: number };
  timeControl?: 'bullet' | 'blitz' | 'rapid' | 'classical';
  pieceCount?: number;
  avoidRepeats: boolean;
}

export interface SearchCriteria {
  rating?: { min: number; max: number };
  themes?: PuzzleThemeType[];
  solved?: boolean;
  source?: PuzzleSource[];
  dateRange?: { from: Date; to: Date };
  tags?: string[];
  limit?: number;
  offset?: number;
}

export interface SolutionResult {
  success: boolean;
  correctMoves: number;
  totalMoves: number;
  timeSpent: number;
  hintsUsed: number;
  accuracy: number;
  newRating?: number;
  achievements?: Achievement[];
  feedback?: SolutionFeedback;
}

export interface SolutionFeedback {
  summary: string;
  strengths: string[];
  weaknesses: string[];
  improvements: string[];
  nextRecommendedTheme?: PuzzleThemeType;
}

export interface Hint {
  type: HintType;
  description: string;
  move?: Move;
  square?: Square;
  reasoning: string;
}

export type HintType = 'suggested-move' | 'piece-highlight' | 'pattern-hint' | 'strategy-hint';

export interface GenerationOptions {
  theme: PuzzleThemeType;
  difficulty: number;
  timeControl?: string;
  maxPly?: number;
  minRating?: number;
  maxRating?: number;
  position?: Position;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
}

export interface ValidationError {
  field: string;
  code: string;
  message: string;
  severity: 'error' | 'critical';
}

export interface ValidationWarning {
  field: string;
  code: string;
  message: string;
  suggestion?: string;
}
```

### 2. Rating Service

```typescript
// src/services/RatingService.ts

export class RatingService {
  // Rating calculation
  calculateNewRating(current: number, performance: PerformanceData): number;
  calculateExpectedScore(playerRating: number, opponentRating: number): number;
  calculatePerformance(achievements: AchievementData[]): number;

  // Difficulty adjustment
  adjustDifficulty(userPerformance: UserPerformance): DifficultyAdjustment;
  getTargetRating(userStats: UserStats): number;
  shouldIncreaseDifficulty(performance: PerformanceMetrics): boolean;

  // Rating history
  getRatingHistory(userId: string, timeRange?: TimeRange): Promise<RatingHistoryEntry[]>;
  predictFutureRating(currentRating: number, trajectory: PerformanceTrend): number;
}

export interface PerformanceData {
  opponentRating: number;
  gameResult: GameResult;
  timeControl: string;
  tournamentCategory?: number;
}

export interface AchievementData {
  puzzleRating: number;
  userRating: number;
  success: boolean;
  timeToSolve: number;
  hintsUsed: number;
}

export interface UserPerformance {
  accuracy: number;
  averageTime: number;
  puzzlesSolved: number;
  consecutiveWins: number;
  consecutiveLosses: number;
  improvementRate: number;
}

export interface DifficultyAdjustment {
  recommendedRating: number;
  adjustment: number;
  reasoning: string;
  confidence: number;
  shouldIncrease: boolean;
  shouldDecrease: boolean;
}

export interface UserStats {
  totalGames: number;
  winRate: number;
  averageOpponentRating: number;
  performanceRating: number;
  recentForm: number;
  volatility: number;
}

export interface TimeRange {
  start: Date;
  end: Date;
}

export interface RatingHistoryEntry {
  date: Date;
  oldRating: number;
  newRating: number;
  change: number;
  source: string;
  gameId?: string;
  opponentRating?: number;
}

export interface PerformanceTrend {
  direction: 'improving' | 'stable' | 'declining';
  rate: number;
  confidence: number;
  projection: RatingProjection[];
}

export interface RatingProjection {
  date: Date;
  predictedRating: number;
  confidence: number;
}
```

### 3. Storage Service

```typescript
// src/services/StorageService.ts

export interface Repository<T> {
  find(id: string): Promise<T | null>;
  findMany(criteria: Partial<T>): Promise<T[]>;
  findByIds(ids: string[]): Promise<(T | null)[]>;
  save(entity: T): Promise<void>;
  saveMany(entities: T[]): Promise<void>;
  delete(id: string): Promise<void>;
  deleteMany(ids: string[]): Promise<void>;
  count(criteria?: Partial<T>): Promise<number>;
  exists(id: string): Promise<boolean>;
  clear(): Promise<void>;
}

export interface CacheRepository<T> extends Repository<T> {
  getCached(id: string): Promise<T | null>;
  cache(entity: T, ttl?: number): Promise<void>;
  invalidate(pattern: string): Promise<void>;
  getStats(): Promise<CacheStats>;
}

export interface StorageStats {
  totalItems: number;
  totalSize: number;
  lastCleanup: Date;
  hitRate: number;
  missRate: number;
}

export interface CacheStats extends StorageStats {
  entries: CacheEntry[];
}

export interface CacheEntry {
  key: string;
  size: number;
  lastAccessed: Date;
  ttl?: number;
}

export interface SyncManager {
  sync(force?: boolean): Promise<SyncResult>;
  isOnline(): boolean;
  isSyncing(): boolean;
  getLastSyncTime(): Date | null;
  queueOperation(operation: SyncOperation): void;
  getPendingOperations(): SyncOperation[];
}

export interface SyncResult {
  success: boolean;
  operationsProcessed: number;
  conflicts: SyncConflict[];
  errors: SyncError[];
  timestamp: Date;
}

export interface SyncOperation {
  id: string;
  type: SyncOperationType;
  entity: string;
  entityId: string;
  data: any;
  timestamp: Date;
  retries: number;
  maxRetries: number;
}

export type SyncOperationType = 'create' | 'update' | 'delete' | 'sync';

export interface SyncConflict {
  id: string;
  operation: SyncOperation;
  localData: any;
  serverData: any;
  resolution?: ConflictResolution;
}

export type ConflictResolution = 'use-local' | 'use-server' | 'merge' | 'manual';

export interface SyncError {
  operationId: string;
  error: string;
  timestamp: Date;
  retryable: boolean;
}
```

---

## Event System

```typescript
// src/core/events/EventBus.ts

export interface EventBus {
  // Subscription
  subscribe<T>(event: string, listener: (data: T) => void): Unsubscribe;
  once<T>(event: string, listener: (data: T) => void): Unsubscribe;
  unsubscribe(event: string, listener: EventListener): void;
  unsubscribeAll(event?: string): void;

  // Publishing
  emit<T>(event: string, data: T): void;
  emitAsync<T>(event: string, data: T): Promise<void>;

  // Utility
  hasListeners(event: string): boolean;
  getListenerCount(event: string): number;
  removeAllListeners(): void;
}

export type EventListener = (data: any) => void;

export type Unsubscribe = () => void;

// Chess Events
export const CHESS_EVENTS = {
  MOVE_PLAYED: 'chess:move-played',
  GAME_STATE_CHANGED: 'chess:game-state-changed',
  CHECK_DETECTED: 'chess:check-detected',
  CHECKMATE_DETECTED: 'chess:checkmate-detected',
  DRAW_DETECTED: 'chess:draw-detected',
  CASTLING_PERFORMED: 'chess:castling-performed',
  PROMOTION_REQUIRED: 'chess:promotion-required'
} as const;

// Puzzle Events
export const PUZZLE_EVENTS = {
  PUZZLE_LOADED: 'puzzle:loaded',
  PUZZLE_SOLVED: 'puzzle:solved',
  PUZZLE_FAILED: 'puzzle:failed',
  HINT_REQUESTED: 'puzzle:hint-requested',
  SOLUTION_SUBMITTED: 'puzzle:solution-submitted',
  NEXT_PUZZLE_LOADED: 'puzzle:next-loaded'
} as const;

// Rating Events
export const RATING_EVENTS = {
  RATING_CHANGED: 'rating:changed',
  RATING_UPDATED: 'rating:updated',
  ACHIEVEMENT_UNLOCKED: 'rating:achievement-unlocked',
  STREAK_CHANGED: 'rating:streak-changed'
} as const;

// Storage Events
export const STORAGE_EVENTS = {
  DATA_SYNCED: 'storage:data-synced',
  CACHE_CLEARED: 'storage:cache-cleared',
  STORAGE_FULL: 'storage:storage-full',
  SYNC_CONFLICT: 'storage:sync-conflict'
} as const;

// UI Events
export const UI_EVENTS = {
  THEME_CHANGED: 'ui:theme-changed',
  ORIENTATION_CHANGED: 'ui:orientation-changed',
  NAVIGATION_CHANGED: 'ui:navigation-changed',
  MODAL_OPENED: 'ui:modal-opened',
  MODAL_CLOSED: 'ui:modal-closed'
} as const;
```

---

## Type Definitions

### Utility Types

```typescript
// src/types/utilities.ts

// Entity types
export type EntityWithId = { id: string };
export type EntityWithTimestamps = {
  createdAt: Date;
  updatedAt: Date;
};
export type EntityWithAudit = EntityWithId & EntityWithTimestamps & {
  createdBy?: string;
  updatedBy?: string;
};

// Result types
export type Result<T, E = Error> =
  | { success: true; data: T }
  | { success: false; error: E };

export type AsyncResult<T, E = Error> = Promise<Result<T, E>>;

// Collection types
export type EntityCollection<T> = Map<string, T>;
export type EntityList<T> = T[];

// Query types
export interface Query<T> {
  filter?: Partial<T>;
  sort?: SortOption<T>;
  pagination?: Pagination;
  projection?: Projection<T>;
}

export interface SortOption<T> {
  field: keyof T;
  direction: 'asc' | 'desc';
}

export interface Pagination {
  page: number;
  limit: number;
  offset?: number;
}

export interface Projection<T> {
  include?: (keyof T)[];
  exclude?: (keyof T)[];
}

// Event types
export interface EventData<T = any> {
  type: string;
  data: T;
  timestamp: Date;
  source: string;
  metadata?: Record<string, any>;
}

// Configuration types
export interface AppConfig {
  version: string;
  environment: 'development' | 'staging' | 'production';
  api: APIConfig;
  storage: StorageConfig;
  features: FeatureFlags;
  analytics: AnalyticsConfig;
}

export interface APIConfig {
  baseURL: string;
  timeout: number;
  retryAttempts: number;
  rateLimit: RateLimitConfig;
}

export interface RateLimitConfig {
  requests: number;
  window: number; // milliseconds
}

export interface StorageConfig {
  maxCacheSize: number;
  cacheTTL: number;
  compressionEnabled: boolean;
  encryptionEnabled: boolean;
}

export interface FeatureFlags {
  stockfishIntegration: boolean;
  customPuzzleGeneration: boolean;
  onlineSync: boolean;
  analytics: boolean;
  crashReporting: boolean;
}

export interface AnalyticsConfig {
  enabled: boolean;
  batchSize: number;
  flushInterval: number;
  trackingId?: string;
}
```

---

## Error Handling

### Error Types

```typescript
// src/types/errors.ts

export class ChessAppError extends Error {
  constructor(
    message: string,
    public code: string,
    public severity: ErrorSeverity = ErrorSeverity.MEDIUM,
    public category: ErrorCategory,
    public details?: any
  ) {
    super(message);
    this.name = 'ChessAppError';
  }
}

export enum ErrorSeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

export enum ErrorCategory {
  VALIDATION = 'validation',
  NETWORK = 'network',
  STORAGE = 'storage',
  LOGIC = 'logic',
  PERMISSION = 'permission',
  SYSTEM = 'system',
  USER_INPUT = 'user-input'
}

// Specific error classes
export class ValidationError extends ChessAppError {
  constructor(message: string, field?: string, value?: any) {
    super(message, 'VALIDATION_ERROR', ErrorSeverity.MEDIUM, ErrorCategory.VALIDATION, {
      field,
      value
    });
    this.name = 'ValidationError';
  }
}

export class NetworkError extends ChessAppError {
  constructor(message: string, statusCode?: number, response?: any) {
    super(message, 'NETWORK_ERROR', ErrorSeverity.MEDIUM, ErrorCategory.NETWORK, {
      statusCode,
      response
    });
    this.name = 'NetworkError';
  }
}

export class StorageError extends ChessAppError {
  constructor(message: string, operation?: string) {
    super(message, 'STORAGE_ERROR', ErrorSeverity.HIGH, ErrorCategory.STORAGE, {
      operation
    });
    this.name = 'StorageError';
  }
}

export class ChessLogicError extends ChessAppError {
  constructor(message: string, position?: string, move?: Move) {
    super(message, 'CHESS_LOGIC_ERROR', ErrorSeverity.HIGH, ErrorCategory.LOGIC, {
      position,
      move
    });
    this.name = 'ChessLogicError';
  }
}

export class PuzzleNotFoundError extends ChessAppError {
  constructor(puzzleId: string) {
    super(`Puzzle not found: ${puzzleId}`, 'PUZZLE_NOT_FOUND', ErrorSeverity.MEDIUM, ErrorCategory.LOGIC, {
      puzzleId
    });
    this.name = 'PuzzleNotFoundError';
  }
}

export class RatingError extends ChessAppError {
  constructor(message: string, currentRating?: number, newRating?: number) {
    super(message, 'RATING_ERROR', ErrorSeverity.MEDIUM, ErrorCategory.LOGIC, {
      currentRating,
      newRating
    });
    this.name = 'RatingError';
  }
}

// Error handler interface
export interface ErrorHandler {
  handle(error: ChessAppError): void;
  report(error: ChessAppError, context?: ErrorContext): void;
  isRecoverable(error: ChessAppError): boolean;
  recover(error: ChessAppError): Promise<void>;
}

export interface ErrorContext {
  userId?: string;
  sessionId?: string;
  operation?: string;
  data?: any;
  timestamp?: Date;
}

// Error recovery strategies
export enum RecoveryStrategy {
  RETRY = 'retry',
  FALLBACK = 'fallback',
  SKIP = 'skip',
  USER_INTERACTION = 'user-interaction',
  RESTART = 'restart',
  IGNORE = 'ignore'
}

export interface ErrorRecovery {
  strategy: RecoveryStrategy;
  maxAttempts: number;
  delay?: number;
  fallback?: any;
}
```

---

## Usage Examples

### Basic Puzzle Service Usage

```typescript
// Example usage of PuzzleService
const puzzleService = new PuzzleService(puzzleRepository, ratingService, cacheService);

// Get next puzzle for user
const puzzle = await puzzleService.getNextPuzzle(1200, {
  themes: ['fork', 'pin'],
  avoidRepeats: true
});

// Submit solution
const result = await puzzleService.submitSolution(puzzle.id, userMoves);

if (result.success) {
  console.log(`Solved in ${result.timeSpent}s with ${result.accuracy}% accuracy`);
} else {
  console.log(`Failed: ${result.feedback?.summary}`);
}
```

### Chess Engine Analysis

```typescript
// Example usage of ChessEngine
const stockfish = new StockfishEngine();
await stockfish.initialize();

const analysis = await stockfish.analyzePosition(
  'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  { depth: 15, time: 1000 }
);

console.log(`Best move: ${analysis.bestMove.notation}`);
console.log(`Evaluation: ${analysis.evaluation.value} centipawns`);
```

### Event System Usage

```typescript
// Example usage of EventBus
const eventBus = new EventBus();

// Subscribe to puzzle solved events
const unsubscribe = eventBus.subscribe('puzzle:solved', (data) => {
  console.log(`Puzzle ${data.puzzleId} solved in ${data.timeSpent}s`);
});

// Emit events
eventBus.emit('puzzle:solved', {
  puzzleId: 'puzzle-123',
  timeSpent: 45,
  accuracy: 100
});

// Cleanup
unsubscribe();
```

---

## Conclusion

This API documentation provides comprehensive interfaces and types for all major components of the Chess Puzzle App. The design emphasizes:

1. **Type Safety**: Strong TypeScript typing throughout
2. **Separation of Concerns**: Clear boundaries between layers
3. **Extensibility**: Easy to add new features and integrations
4. **Error Handling**: Comprehensive error types and recovery
5. **Event-Driven Architecture**: Loose coupling through events
6. **Framework Agnosticism**: Core logic independent of React Native

The documentation serves as a complete reference for developers implementing the Chess Puzzle App following the Kilo Code Software Development Rules.

---

**Document Version**: 1.0
**Last Updated**: 2025-01-27
**API Version**: 1.0.0