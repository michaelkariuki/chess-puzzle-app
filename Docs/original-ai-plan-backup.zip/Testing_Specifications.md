# Chess Puzzle App - Testing Specifications & Quality Assurance

## Table of Contents

1. [Testing Strategy Overview](#testing-strategy-overview)
2. [Testing Pyramid Implementation](#testing-pyramid-implementation)
3. [Unit Testing Specifications](#unit-testing-specifications)
4. [Integration Testing Specifications](#integration-testing-specifications)
5. [End-to-End Testing Specifications](#end-to-end-testing-specifications)
6. [Performance Testing](#performance-testing)
7. [Test Automation Framework](#test-automation-framework)
8. [Code Quality Standards](#code-quality-standards)
9. [Continuous Integration](#continuous-integration)
10. [Quality Metrics](#quality-metrics)

---

## Testing Strategy Overview

### Testing Philosophy

Following the Kilo Code Software Development Rules, our testing strategy emphasizes:

1. **Framework-Agnostic Testing**: Core business logic tested independently of React Native
2. **Analysis-First Testing**: Test design driven by requirements analysis
3. **Quality Assurance**: Comprehensive coverage with measurable quality gates

### Testing Pyramid

```
                    ┌─────────────────┐
                    │  E2E Tests      │  ← 10% (Critical paths)
                    │  (Detox)        │
                    └─────────────────┘
              ┌─────────────────────────────┐
              │      Integration Tests     │  ← 20% (Component interaction)
              │     (Jest + Testing        │
              │      Library)              │
              └─────────────────────────────┘
        ┌─────────────────────────────────────────┐
        │              Unit Tests                  │  ← 70% (Core logic)
        │         (Jest)                          │
        └─────────────────────────────────────────┘
```

### Coverage Targets

| Test Type | Coverage Target | Critical Path Coverage |
|-----------|----------------|----------------------|
| Unit Tests | >90% | 100% |
| Integration Tests | >80% | 100% |
| E2E Tests | 100% of critical paths | 100% |
| Performance Tests | All major features | 100% |

---

## Testing Pyramid Implementation

### 1. Unit Testing Layer (70%)

**Scope**: Core business logic, chess mechanics, rating calculations, utilities
**Tools**: Jest, React Native Testing Library (for React components)
**Isolation**: No external dependencies, pure functions

```typescript
// Example unit test structure
describe('Chess Position', () => {
  describe('FEN Parsing', () => {
    test('should parse valid FEN notation', () => {
      const fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
      const position = new Position(fen);

      expect(position.getTurn()).toBe('white');
      expect(position.getCastlingRights()).toEqual({
        whiteKingside: true,
        whiteQueenside: true,
        blackKingside: true,
        blackQueenside: true
      });
    });

    test('should reject invalid FEN notation', () => {
      const invalidFen = 'invalid-fen-string';

      expect(() => new Position(invalidFen)).toThrow(ValidationError);
    });
  });
});
```

### 2. Integration Testing Layer (20%)

**Scope**: API integration, storage operations, component interactions
**Tools**: Jest, React Native Testing Library, MSW (Mock Service Worker)
**Focus**: Contract testing between modules

```typescript
// Example integration test
describe('Lichess API Integration', () => {
  beforeEach(() => {
    server.resetHandlers();
  });

  test('should fetch and parse puzzle correctly', async () => {
    const mockPuzzle = {
      id: 'test-123',
      fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
      solution: ['e2e4'],
      rating: 1200
    };

    server.use(
      rest.get('/api/puzzle/daily', (req, res, ctx) => {
        return res(ctx.json({ puzzles: [mockPuzzle] }));
      })
    );

    const api = new LichessAPIClient(httpClient);
    const puzzle = await api.fetchDailyPuzzle();

    expect(puzzle.id).toBe('test-123');
    expect(puzzle.rating).toBe(1200);
  });
});
```

### 3. End-to-End Testing Layer (10%)

**Scope**: Critical user journeys, offline functionality, app launch
**Tools**: Detox for React Native E2E testing
**Coverage**: 100% of critical user paths

```typescript
// Example E2E test
describe('Puzzle Solving Flow', () => {
  beforeAll(async () => {
    await device.reloadReactNative();
  });

  it('should solve a puzzle completely', async () => {
    // Navigate to puzzle
    await element(by.id('home-new-puzzle')).tap();
    await waitFor(element(by.id('chess-board'))).toBeVisible().withTimeout(5000);

    // Make moves
    await element(by.id('square-e2')).tap();
    await element(by.id('square-e4')).tap();

    // Verify solution
    await expect(element(by.id('solution-feedback'))).toBeVisible();
    await expect(element(by.id('next-puzzle-button'))).toBeVisible();
  });
});
```

---

## Unit Testing Specifications

### 1. Chess Logic Testing

#### Position Validation Tests
```typescript
// __tests__/unit/core/chess/Position.test.ts
import { Position, Move, Square, ValidationError } from '../../../../src/core/chess';

describe('Position', () => {
  describe('FEN Validation', () => {
    const validFEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

    test('should accept valid starting position', () => {
      expect(() => new Position(validFEN)).not.toThrow();
    });

    test('should reject invalid piece placement', () => {
      const invalidFEN = 'invalid/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
      expect(() => new Position(invalidFEN)).toThrow(ValidationError);
    });

    test('should reject invalid side to move', () => {
      const invalidFEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR x KQkq - 0 1';
      expect(() => new Position(invalidFEN)).toThrow(ValidationError);
    });
  });

  describe('Move Generation', () => {
    let position: Position;

    beforeEach(() => {
      position = new Position('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
    });

    test('should generate exactly 20 moves from starting position', () => {
      const legalMoves = position.getLegalMoves();
      expect(legalMoves).toHaveLength(20);
    });

    test('should generate correct pawn moves from starting position', () => {
      const pawnMoves = position.getLegalMoves().filter(move =>
        move.piece.type === 'pawn'
      );
      expect(pawnMoves).toHaveLength(16);
    });

    test('should generate correct knight moves', () => {
      const knightMoves = position.getLegalMoves().filter(move =>
        move.piece.type === 'knight'
      );
      expect(knightMoves).toHaveLength(8);
    });

    test('should not generate illegal moves into check', () => {
      const checkPosition = new Position('6k1/5ppp/8/8/8/8/8/R3K2R w KQ - 0 1');
      const illegalMoves = checkPosition.getLegalMoves().filter(move =>
        move.castle || move.toSquare === 'a1' || move.toSquare === 'h1'
      );
      expect(illegalMoves).toHaveLength(0);
    });
  });

  describe('Move Application', () => {
    test('should correctly apply a simple pawn move', () => {
      const position = new Position('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
      const move = new Move('e2', 'e4');

      const newPosition = position.applyMove(move);

      expect(newPosition.getPieceAt('e4')).toBeDefined();
      expect(newPosition.getPieceAt('e2')).toBeNull();
      expect(newPosition.getTurn()).toBe('black');
    });

    test('should handle castling correctly', () => {
      const castlingPosition = new Position('r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1');
      const castleMove = new Move('e1', 'g1', { castle: 'kingside' });

      const newPosition = castlingPosition.applyMove(castleMove);

      expect(newPosition.getPieceAt('g1')?.type).toBe('king');
      expect(newPosition.getPieceAt('f1')?.type).toBe('rook');
      expect(newPosition.getCastlingRights().whiteKingside).toBe(false);
    });
  });
});
```

#### Move Validation Tests
```typescript
// __tests__/unit/core/chess/Move.test.ts
import { Move, Square, Piece, MoveValidator } from '../../../../src/core/chess';

describe('Move', () => {
  describe('Move Creation', () => {
    test('should create valid UCI notation', () => {
      const fromSquare = new Square('e', 2);
      const toSquare = new Square('e', 4);
      const move = new Move(fromSquare, toSquare);

      expect(move.toUCI()).toBe('e2e4');
    });

    test('should create promotion move notation', () => {
      const fromSquare = new Square('a', 7);
      const toSquare = new Square('a', 8);
      const move = new Move(fromSquare, toSquare, { promotion: 'queen' });

      expect(move.toUCI()).toBe('a7a8q');
    });
  });

  describe('Move Validation', () => {
    let validator: MoveValidator;
    let position: Position;

    beforeEach(() => {
      validator = new MoveValidator();
      position = new Position('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
    });

    test('should validate legal moves', () => {
      const move = new Move('e2', 'e4');
      expect(validator.isLegalMove(position, move)).toBe(true);
    });

    test('should reject moves to occupied squares', () => {
      const move = new Move('e2', 'e1');
      expect(validator.isLegalMove(position, move)).toBe(false);
    });

    test('should reject moves for wrong color', () => {
      const move = new Move('e7', 'e5');
      expect(validator.isLegalMove(position, move)).toBe(false);
    });
  });
});
```

### 2. Puzzle Logic Testing

#### Puzzle Solution Testing
```typescript
// __tests__/unit/core/puzzles/Solver.test.ts
import { PuzzleSolver } from '../../../../src/core/puzzles';
import { Position } from '../../../../src/core/chess';

describe('PuzzleSolver', () => {
  let solver: PuzzleSolver;

  beforeEach(() => {
    solver = new PuzzleSolver();
  });

  test('should validate correct solution', async () => {
    const fen = 'rnbqkb1r/pp1p1ppp/5n2/2B1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 4';
    const solution = ['d4', 'h6', 'Bxh6', 'gxh6'];
    const position = new Position(fen);

    const result = await solver.validateSolution(position, solution);

    expect(result.success).toBe(true);
    expect(result.correctMoves).toBe(4);
    expect(result.mistakes).toHaveLength(0);
  });

  test('should detect incorrect move', async () => {
    const fen = 'rnbqkb1r/pp1p1ppp/5n2/2B1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 4';
    const incorrectMoves = ['d4', 'h5', 'Bxh6', 'gxh6']; // Wrong move: h5 instead of h6
    const position = new Position(fen);

    const result = await solver.validateSolution(position, incorrectMoves);

    expect(result.success).toBe(false);
    expect(result.mistakes[0].move).toBe('h5');
    expect(result.mistakes[0].expectedMove).toBe('h6');
  });

  test('should provide hints for failed solutions', async () => {
    const fen = 'rnbqkb1r/pp1p1ppp/5n2/2B1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 4';
    const userMoves = ['d4']; // First move correct, stops here
    const position = new Position(fen);

    const hints = await solver.generateHints(position, 1);

    expect(hints).toHaveLength(1);
    expect(hints[0].type).toBe('suggested-move');
    expect(hints[0].square).toBe('h6');
  });
});
```

### 3. Rating System Testing

#### Elo Rating Calculation Tests
```typescript
// __tests__/unit/core/rating/Elo.test.ts
import { EloRatingSystem } from '../../../../src/core/rating';

describe('EloRatingSystem', () => {
  let ratingSystem: EloRatingSystem;

  beforeEach(() => {
    ratingSystem = new EloRatingSystem();
  });

  describe('Expected Score Calculation', () => {
    test('should calculate expected score for equal players', () => {
      const expected = ratingSystem.calculateExpectedScore(1500, 1500);
      expect(expected).toBeCloseTo(0.5, 2);
    });

    test('should calculate expected score for stronger player', () => {
      const expected = ratingSystem.calculateExpectedScore(1600, 1400);
      expect(expected).toBeGreaterThan(0.5);
      expect(expected).toBeLessThan(0.8);
    });

    test('should calculate expected score for weaker player', () => {
      const expected = ratingSystem.calculateExpectedScore(1400, 1600);
      expect(expected).toBeLessThan(0.5);
      expect(expected).toBeGreaterThan(0.2);
    });
  });

  describe('Rating Updates', () => {
    test('should update rating after win', () => {
      const newRating = ratingSystem.calculateNewRating(
        1500,
        { opponentRating: 1500, result: 'win', kFactor: 32 }
      );

      expect(newRating).toBeGreaterThan(1500);
      expect(newRating).toBeLessThan(1532); // Maximum gain with K=32
    });

    test('should update rating after loss', () => {
      const newRating = ratingSystem.calculateNewRating(
        1500,
        { opponentRating: 1500, result: 'loss', kFactor: 32 }
      );

      expect(newRating).toBeLessThan(1500);
      expect(newRating).toBeGreaterThan(1468); // Maximum loss with K=32
    });

    test('should update rating after draw', () => {
      const newRating = ratingSystem.calculateNewRating(
        1500,
        { opponentRating: 1500, result: 'draw', kFactor: 32 }
      );

      expect(newRating).toBeCloseTo(1500, 0); // Should be very close to original
    });
  });
});
```

---

## Integration Testing Specifications

### 1. API Integration Tests

#### Lichess API Integration
```typescript
// __tests__/integration/api/LichessAPI.test.ts
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { LichessAPIClient } from '../../../src/adapters/external/LichessAPI';

describe('Lichess API Integration', () => {
  let server: ReturnType<typeof setupServer>;
  let apiClient: LichessAPIClient;

  beforeAll(() => {
    server = setupServer(
      rest.get('https://lichess.org/api/puzzle/daily', (req, res, ctx) => {
        return res(
          ctx.json({
            puzzles: [
              {
                id: 'test-123',
                fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
                solution: ['e2e4'],
                rating: 1200,
                themes: ['tactical']
              }
            ]
          })
        );
      }),
      rest.get('https://lichess.org/api/puzzle/batch', (req, res, ctx) => {
        return res(
          ctx.json({
            puzzles: [
              {
                id: 'test-124',
                fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
                solution: ['g1f3'],
                rating: 1000,
                themes: ['development']
              }
            ]
          })
        );
      })
    );

    server.listen();
  });

  afterEach(() => {
    server.resetHandlers();
  });

  afterAll(() => {
    server.close();
  });

  test('should fetch daily puzzle successfully', async () => {
    const puzzle = await apiClient.fetchDailyPuzzle();

    expect(puzzle).toBeDefined();
    expect(puzzle.id).toBe('test-123');
    expect(puzzle.solution).toHaveLength(1);
    expect(puzzle.rating).toBe(1200);
  });

  test('should handle API errors gracefully', async () => {
    server.use(
      rest.get('https://lichess.org/api/puzzle/daily', (req, res, ctx) => {
        return res(ctx.status(500), ctx.json({ error: 'Internal server error' }));
      })
    );

    await expect(apiClient.fetchDailyPuzzle()).rejects.toThrow(NetworkError);
  });

  test('should respect rate limiting', async () => {
    const startTime = Date.now();
    const requests = Array(60).fill(null).map(() =>
      apiClient.fetchDailyPuzzle().catch(() => null)
    );

    await Promise.all(requests);
    const elapsed = Date.now() - startTime;

    // Should take at least 1 second due to rate limiting
    expect(elapsed).toBeGreaterThan(1000);
  });
});
```

### 2. Storage Integration Tests

#### AsyncStorage Integration
```typescript
// __tests__/integration/storage/AsyncStorage.test.ts
import AsyncStorage from '@react-native-async-storage/async-storage';
import { PuzzleRepository } from '../../../src/core/storage';

describe('Puzzle Repository Integration', () => {
  let repository: PuzzleRepository;

  beforeEach(async () => {
    await AsyncStorage.clear();
    repository = new PuzzleRepository(new AsyncStorageAdapter(), new CacheManager());
  });

  afterAll(async () => {
    await AsyncStorage.clear();
  });

  test('should save and retrieve puzzle', async () => {
    const puzzle = {
      id: 'test-puzzle',
      fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
      solution: ['e2e4'],
      rating: 1200
    };

    await repository.save(puzzle);
    const retrieved = await repository.find('test-puzzle');

    expect(retrieved).toEqual(puzzle);
  });

  test('should cache frequently accessed puzzles', async () => {
    const puzzle = {
      id: 'frequent-puzzle',
      fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
      solution: ['e2e4'],
      rating: 1000
    };

    await repository.save(puzzle);

    // Access multiple times
    await Promise.all([
      repository.find('frequent-puzzle'),
      repository.find('frequent-puzzle'),
      repository.find('frequent-puzzle')
    ]);

    // Should be cached (verify through cache stats)
    const stats = await repository.getCacheStats();
    expect(stats.hitRate).toBeGreaterThan(0.5);
  });

  test('should handle storage quota exceeded', async () => {
    // Fill storage to near capacity
    const largePuzzle = generateLargePuzzle('large-puzzle');
    await repository.save(largePuzzle);

    // Should handle quota exceeded gracefully
    await expect(repository.save(generateLargePuzzle('another-large'))).rejects.toThrow(StorageError);
  });
});
```

### 3. Service Integration Tests

#### Complete Workflow Tests
```typescript
// __tests__/integration/services/CompleteWorkflow.test.ts
describe('Complete Puzzle Solving Workflow', () => {
  test('should complete full puzzle flow end-to-end', async () => {
    // 1. Get puzzle from service
    const puzzleService = new PuzzleService(
      puzzleRepository,
      ratingService,
      cacheService
    );

    const user = await userService.getCurrentUser();
    const puzzle = await puzzleService.getNextPuzzle(user.rating);

    // 2. Solve puzzle
    const position = new Position(puzzle.fen);
    const solutionResult = await puzzleService.submitSolution(
      puzzle.id,
      puzzle.solution
    );

    expect(solutionResult.success).toBe(true);
    expect(solutionResult.newRating).toBeDefined();

    // 3. Verify state updates
    const updatedUser = await userService.getCurrentUser();
    expect(updatedUser.rating).not.toBe(user.rating);
    expect(updatedUser.progress.totalSolved).toBe(1);

    // 4. Verify caching behavior
    const cachedPuzzle = await puzzleRepository.find(puzzle.id);
    expect(cachedPuzzle?.userProgress?.solved).toBe(true);
  });
});
```

---

## End-to-End Testing Specifications

### 1. Critical User Journeys

#### Puzzle Solving Flow
```typescript
// __tests__/e2e/puzzle-solving.e2e.ts
describe('Puzzle Solving E2E', () => {
  beforeAll(async () => {
    await device.reloadReactNative();
  });

  beforeEach(async () => {
    // Ensure clean state
    await element(by.id('reset-app')).tap();
    await waitFor(element(by.id('welcome-screen'))).toBeVisible().withTimeout(2000);
  });

  describe('Happy Path - Solving a Puzzle', () => {
    it('should complete puzzle solving flow', async () => {
      // 1. Launch app and start new puzzle
      await element(by.id('new-puzzle-button')).tap();
      await waitFor(element(by.id('chess-board'))).toBeVisible().withTimeout(5000);

      // 2. Verify puzzle loaded
      await expect(element(by.id('puzzle-rating'))).toHaveText('Rating: 1200');
      await expect(element(by.id('moves-remaining'))).toHaveText('Moves: 3');

      // 3. Make correct moves
      await element(by.id('square-e2')).tap();
      await element(by.id('square-e4')).tap();

      await waitFor(element(by.id('move-feedback-success'))).toBeVisible().withTimeout(1000);

      await element(by.id('square-h6')).tap();
      await element(by.id('square-h6-piece')).tap();

      await element(by.id('square-g5')).tap();
      await element(by.id('square-h4')).tap();

      // 4. Verify completion
      await waitFor(element(by.id('puzzle-completed'))).toBeVisible().withTimeout(2000);
      await expect(element(by.id('success-message'))).toBeVisible();
      await expect(element(by.id('rating-change'))).toBeVisible();

      // 5. Navigate to next puzzle
      await element(by.id('next-puzzle-button')).tap();
      await waitFor(element(by.id('chess-board'))).toBeVisible().withTimeout(2000);
    });
  });

  describe('Error Path - Failed Puzzle Attempt', () => {
    it('should handle incorrect moves gracefully', async () => {
      await element(by.id('new-puzzle-button')).tap();
      await waitFor(element(by.id('chess-board'))).toBeVisible();

      // Make incorrect move
      await element(by.id('square-e2')).tap();
      await element(by.id('square-e3')).tap(); // Wrong move

      await waitFor(element(by.id('move-feedback-error'))).toBeVisible().withTimeout(1000);
      await expect(element(by.id('hint-button'))).toBeVisible();

      // Request hint
      await element(by.id('hint-button')).tap();
      await expect(element(by.id('hint-display'))).toBeVisible();
    });
  });
});
```

#### Offline Mode Testing
```typescript
// __tests__/e2e/offline-mode.e2e.ts
describe('Offline Mode E2E', () => {
  beforeAll(async () => {
    await device.reloadReactNative();
  });

  it('should work completely offline', async () => {
    // 1. Pre-load puzzles while online
    await element(by.id('settings-button')).tap();
    await element(by.id('preload-puzzles-button')).tap();
    await waitFor(element(by.id('preload-complete'))).toBeVisible().withTimeout(5000);

    await element(by.id('back-to-home')).tap();

    // 2. Enable offline mode
    await element(by.id('settings-button')).tap();
    await element(by.id('offline-mode-toggle')).tap();

    // 3. Disconnect network (simulate in tests)
    await device.setNetworkConnection('none');

    // 4. Solve puzzles offline
    for (let i = 0; i < 3; i++) {
      await element(by.id('new-puzzle-button')).tap();
      await waitFor(element(by.id('chess-board'))).toBeVisible().withTimeout(2000);

      // Solve puzzle...
      await solveCurrentPuzzle();

      await waitFor(element(by.id('puzzle-completed'))).toBeVisible().withTimeout(2000);
      await element(by.id('next-puzzle-button')).tap();
    }

    // 5. Reconnect and sync
    await device.setNetworkConnection('wifi');
    await element(by.id('sync-button')).tap();

    await waitFor(element(by.id('sync-complete'))).toBeVisible().withTimeout(3000);
    await expect(element(by.id('sync-stats'))).toContainText('3 puzzles synced');
  });
});
```

### 2. Performance E2E Tests

#### App Launch Performance
```typescript
// __tests__/e2e/performance.e2e.ts
describe('Performance E2E Tests', () => {
  it('should launch app within 3 seconds', async () => {
    const startTime = Date.now();

    await device.launchApp();

    await waitFor(element(by.id('home-screen'))).toBeVisible().withTimeout(3000);

    const launchTime = Date.now() - startTime;
    expect(launchTime).toBeLessThan(3000);
  });

  it('should switch screens within 500ms', async () => {
    await element(by.id('settings-button')).tap();
    const startTime = Date.now();

    await waitFor(element(by.id('settings-screen'))).toBeVisible().withTimeout(1000);

    const switchTime = Date.now() - startTime;
    expect(switchTime).toBeLessThan(500);
  });

  it('should load puzzle within 1 second', async () => {
    await element(by.id('new-puzzle-button')).tap();
    const startTime = Date.now();

    await waitFor(element(by.id('chess-board-ready'))).toBeVisible().withTimeout(1000);

    const loadTime = Date.now() - startTime;
    expect(loadTime).toBeLessThan(1000);
  });
});
```

---

## Performance Testing

### 1. Memory Usage Testing

```typescript
// __tests__/performance/MemoryUsage.test.ts
describe('Memory Usage Performance', () => {
  test('should not leak memory during puzzle solving', async () => {
    const initialMemory = await getMemoryUsage();

    // Solve 100 puzzles rapidly
    for (let i = 0; i < 100; i++) {
      const puzzle = await puzzleService.getNextPuzzle(1200);
      await puzzleService.submitSolution(puzzle.id, puzzle.solution);

      // Force garbage collection if available
      if (global.gc) {
        global.gc();
      }
    }

    const finalMemory = await getMemoryUsage();
    const memoryIncrease = finalMemory.usedJSHeapSize - initialMemory.usedJSHeapSize;

    // Memory increase should be less than 10MB
    expect(memoryIncrease).toBeLessThan(10 * 1024 * 1024);
  });

  test('should handle large puzzle datasets efficiently', async () => {
    const startTime = performance.now();
    const startMemory = await getMemoryUsage();

    // Load 1000 puzzles
    const puzzles = await puzzleRepository.findMany({ limit: 1000 });
    expect(puzzles).toHaveLength(1000);

    const loadTime = performance.now() - startTime;
    const memoryUsed = await getMemoryUsage();

    // Should load within 5 seconds
    expect(loadTime).toBeLessThan(5000);

    // Should use less than 50MB
    expect(memoryUsed.usedJSHeapSize).toBeLessThan(50 * 1024 * 1024);
  });
});
```

### 2. Rendering Performance

```typescript
// __tests__/performance/ChessBoardRendering.test.ts
describe('Chess Board Rendering Performance', () => {
  test('should render chess board at 60fps', async () => {
    const position = new Position('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
    const frames: number[] = [];

    // Measure frame rate during rendering
    const startTime = performance.now();
    const frameCount = 60;

    for (let i = 0; i < frameCount; i++) {
      const frameStart = performance.now();
      renderChessBoard(position);
      frames.push(performance.now() - frameStart);
    }

    const totalTime = performance.now() - startTime;
    const avgFrameTime = frames.reduce((a, b) => a + b, 0) / frames.length;

    // Should maintain 60fps (16.67ms per frame)
    expect(avgFrameTime).toBeLessThan(16.67);
    expect(totalTime).toBeLessThan(1000); // 60 frames in 1 second
  });

  test('should handle smooth animations', async () => {
    const startTime = performance.now();

    // Trigger animation
    await animatePieceMove('e2', 'e4');

    const animationTime = performance.now() - startTime;

    // Animation should complete within 300ms
    expect(animationTime).toBeLessThan(300);
  });
});
```

---

## Test Automation Framework

### 1. Jest Configuration

```javascript
// jest.config.js
module.exports = {
  preset: 'jest-expo',
  transformIgnorePatterns: [
    'node_modules/(?!((jest-)?react-native|@react-native(-community)?)|expo(nent)?|@expo(nent)?/.*|@expo-google-fonts/.*|react-navigation|@react-navigation/.*|@unimodules/.*|unimodules|sentry-expo|native-base|react-native-svg)'
  ],
  setupFilesAfterEnv: [
    '<rootDir>/__tests__/setup.ts',
    '<rootDir>/__tests__/setupAfterEnv.ts'
  ],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  testMatch: [
    '<rootDir>/__tests__/unit/**/*.test.{ts,tsx}',
    '<rootDir>/__tests__/integration/**/*.test.{ts,tsx}',
    '<rootDir>/__tests__/performance/**/*.test.{ts,tsx}'
  ],
  collectCoverageFrom: [
    'src/core/**/*.{ts,tsx}',
    'src/services/**/*.{ts,tsx}',
    'src/adapters/**/*.{ts,tsx}',
    '!src/**/*.d.ts',
    '!src/**/*.stories.{ts,tsx}'
  ],
  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'lcov', 'html'],
  coverageThreshold: {
    global: {
      branches: 85,
      functions: 90,
      lines: 90,
      statements: 90
    },
    // Specific thresholds for critical modules
    './src/core/chess/': {
      branches: 95,
      functions: 95,
      lines: 95,
      statements: 95
    },
    './src/core/puzzles/': {
      branches: 90,
      functions: 90,
      lines: 90,
      statements: 90
    }
  },
  testEnvironment: 'jsdom',
  setupFiles: ['<rootDir>/jest.setup.js'],
  moduleNameMapping: {
    '^@/(.*)$': '<rootDir>/src/$1',
    '^@core/(.*)$': '<rootDir>/src/core/$1',
    '^@adapters/(.*)$': '<rootDir>/src/adapters/$1',
    '^@services/(.*)$': '<rootDir>/src/services/$1'
  }
};
```

### 2. Detox Configuration

```javascript
// detox.config.js
module.exports = {
  testRunner: {
    args: {
      config: 'e2e/jest.config.js'
    }
  },
  configurations: {
    'ios.sim.debug': {
      binaryPath: 'ios/build/Build/Products/Debug-iphonesimulator/ChessPuzzleApp.app',
      build: 'xcodebuild -workspace ios/ChessPuzzleApp.xcworkspace -scheme ChessPuzzleApp -configuration Debug -sdk iphonesimulator -derivedDataPath ios/build',
      type: 'ios.simulator',
      device: {
        type: 'iPhone 13'
      }
    },
    'ios.sim.release': {
      binaryPath: 'ios/build/Build/Products/Release-iphonesimulator/ChessPuzzleApp.app',
      build: 'xcodebuild -workspace ios/ChessPuzzleApp.xcworkspace -scheme ChessPuzzleApp -configuration Release -sdk iphonesimulator -derivedDataPath ios/build',
      type: 'ios.simulator',
      device: {
        type: 'iPhone 13'
      }
    },
    'android.emu.debug': {
      binaryPath: 'android/app/build/outputs/apk/debug/app-debug.apk',
      build: 'cd android && ./gradlew assembleDebug assembleAndroidTest -DtestBuildType=debug',
      type: 'android.emulator',
      device: {
        avdName: 'Pixel_3a_API_30_x86'
      }
    }
  },
  apps: {
    'ios.debug': {
      type: 'ios.app',
      binaryPath: 'ios/build/Build/Products/Debug-iphonesimulator/ChessPuzzleApp.app'
    },
    'android.debug': {
      type: 'android.apk',
      binaryPath: 'android/app/build/outputs/apk/debug/app-debug.apk'
    }
  },
  devices: {
    simulator: {
      type: 'ios.simulator',
      device: {
        type: 'iPhone 13'
      }
    },
    emulator: {
      type: 'android.emulator',
      device: {
        avdName: 'Pixel_3a_API_30_x86'
      }
    }
  }
};
```

### 3. Test Scripts

```json
{
  "scripts": {
    "test": "jest",
    "test:watch": "jest --watch",
    "test:coverage": "jest --coverage --watchAll=false",
    "test:unit": "jest --testPathPattern=unit --watchAll=false",
    "test:integration": "jest --testPathPattern=integration --watchAll=false",
    "test:performance": "jest --testPathPattern=performance --watchAll=false",
    "test:e2e:ios": "detox test --configuration ios.sim.debug",
    "test:e2e:android": "detox test --configuration android.emu.debug",
    "test:e2e:build:ios": "detox build --configuration ios.sim.debug",
    "test:e2e:build:android": "detox build --configuration android.emu.debug",
    "test:all": "npm run test:unit && npm run test:integration && npm run test:e2e:ios"
  }
}
```

---

## Code Quality Standards

### 1. TypeScript Configuration

```json
// tsconfig.json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "ESNext",
    "moduleResolution": "node",
    "lib": ["ES2020", "DOM"],
    "jsx": "react-native",
    "allowJs": true,
    "noEmit": true,
    "isolatedModules": true,
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true,
    "noImplicitOverride": true,
    "noPropertyAccessFromIndexSignature": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "allowSyntheticDefaultImports": true,
    "esModuleInterop": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "baseUrl": "./src",
    "paths": {
      "@/*": ["*"],
      "@core/*": ["core/*"],
      "@adapters/*": ["adapters/*"],
      "@services/*": ["services/*"],
      "@types/*": ["types/*"],
      "@constants/*": ["constants/*"]
    }
  },
  "include": [
    "src/**/*",
    "__tests__/**/*",
    "*.ts",
    "*.tsx"
  ],
  "exclude": [
    "node_modules",
    "dist",
    "build"
  ]
}
```

### 2. ESLint Configuration

```json
{
  "extends": [
    "@react-native-community",
    "@typescript-eslint/recommended",
    "plugin:sonarjs/recommended",
    "plugin:jest/recommended"
  ],
  "parser": "@typescript-eslint/parser",
  "plugins": [
    "@typescript-eslint",
    "sonarjs",
    "jest"
  ],
  "rules": {
    "no-console": "error",
    "no-debugger": "error",
    "prefer-const": "error",
    "no-var": "error",
    "object-shorthand": "error",
    "prefer-template": "error",
    "@typescript-eslint/explicit-function-return-type": "error",
    "@typescript-eslint/no-explicit-any": "error",
    "@typescript-eslint/no-unused-vars": "error",
    "@typescript-eslint/no-non-null-assertion": "error",
    "sonarjs/cognitive-complexity": ["error", 15],
    "sonarjs/no-duplicate-string": ["error", 3],
    "jest/no-disabled-tests": "error",
    "jest/no-focused-tests": "error"
  },
  "env": {
    "react-native/react-native": true,
    "jest/globals": true
  },
  "settings": {
    "react-native/version": "detect"
  }
}
```

### 3. Prettier Configuration

```json
{
  "semi": true,
  "trailingComma": "es5",
  "singleQuote": true,
  "printWidth": 100,
  "tabWidth": 2,
  "useTabs": false,
  "bracketSpacing": true,
  "bracketSameLine": false,
  "arrowParens": "avoid",
  "endOfLine": "lf"
}
```

---

## Continuous Integration

### 1. GitHub Actions Workflow

```yaml
# .github/workflows/ci.yml
name: Continuous Integration

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  lint-and-type-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      - run: npm ci
      - run: npm run lint
      - run: npm run type-check

  unit-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      - run: npm ci
      - run: npm run test:unit
      - name: Upload coverage reports
        uses: codecov/codecov-action@v3
        with:
          file: ./coverage/lcov.info

  integration-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      - run: npm ci
      - run: npm run test:integration

  e2e-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      - run: npm ci
      - name: Build iOS App
        run: npm run test:e2e:build:ios
      - name: Run iOS E2E Tests
        run: npm run test:e2e:ios

  security-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run security audit
        run: npm audit --audit-level moderate
      - name: Run CodeQL Analysis
        uses: github/codeql-action/init@v2
        with:
          languages: javascript
```

---

## Quality Metrics

### 1. Coverage Requirements

| Component | Line Coverage | Branch Coverage | Function Coverage |
|-----------|---------------|-----------------|-------------------|
| Core Chess Logic | >95% | >95% | >95% |
| Puzzle Logic | >90% | >90% | >90% |
| Rating System | >90% | >90% | >90% |
| Services | >85% | >85% | >85% |
| React Components | >80% | >80% | >80% |
| Utils/Helpers | >95% | >95% | >95% |

### 2. Performance Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| App Launch Time | <3s | Cold start to home screen |
| Puzzle Load Time | <1s | FEN to rendered board |
| Move Validation | <100ms | Click to move feedback |
| Memory Usage | <100MB | After 1 hour of usage |
| Bundle Size | <50MB | Production APK/IPA |

### 3. Quality Gates

```yaml
quality_gates:
  code_coverage:
    minimum: 85%
    critical_paths: 100%

  performance:
    lighthouse_score: >90
    app_launch: <3s
    memory_usage: <100MB

  security:
    vulnerabilities: none
    security_audit: pass

  testing:
    unit_tests: pass
    integration_tests: pass
    e2e_tests: pass

  code_quality:
    linting: pass
    typescript: pass
    formatting: pass
```

---

## Conclusion

This comprehensive testing strategy ensures:

1. **High-Quality Code**: Through systematic unit, integration, and E2E testing
2. **Performance Standards**: Measured and enforced through performance tests
3. **Quality Gates**: Automated checks prevent regressions
4. **Framework Independence**: Core logic tested without framework dependencies
5. **Continuous Improvement**: Metrics-driven quality enhancement

The testing framework provides confidence in the Chess Puzzle App's reliability, performance, and maintainability while following the Kilo Code Software Development Rules for quality-first development.

---

**Document Version**: 1.0
**Last Updated**: 2025-01-27
**Testing Framework**: Jest + Detox + MSW
**Coverage Target**: 90% overall, 95% critical paths